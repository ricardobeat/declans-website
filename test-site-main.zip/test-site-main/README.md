# test-site

1. Clone this repository
2. Go to 'Settings -> Pages' and enable it deploying from the `main` branch

## Editing

Fast option:

1. Click index.html (or styles.css) and the 'Edit' button in the top right, edit and commit changes. You must know what you're doing as there is no preview :)

With preview:

1. Enable Codespaces in the repo (press `.` to enter the codespace)
2. In the left sidebar, go to 'Extensions' and install 'Quick HTML Previewer'
3. Now open `index.html`, press Cmd+P to open the command palette, and run 'Side preview' to see edits in real time (you might have to open styles.css for the styles to apply to the preview)
4. Use the 'Source Control' tab in the sidebar to commit changes
